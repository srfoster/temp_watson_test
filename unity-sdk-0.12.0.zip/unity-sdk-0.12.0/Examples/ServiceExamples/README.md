# Service Examples

The example Unity scene contains GameObjects attached with examples on how to access the low level services directly without using Widgets. 

## Usage

Run the Unity Editor with the desired GameObject enabled. Output will be displayed in the Console.
